/**
 * @file
 * Contains an implementation of the extractMessage function.
 */

#include <iostream> // might be useful for debugging
#include <assert.h>
#include "extractMessage.h"
#include <vector>
#include <math.h>
#include <stack>
using namespace std;

unsigned char *extractMessage(const unsigned char *message_in, int length) {
    // length must be a multiple of 8
    assert((length % 8) == 0);

    // allocate an array for the output
    unsigned char *message_out = new unsigned char[length];
    for (int i = 0; i < length; i++) {
        message_out[i] = 0;
    }
    // int orig[8][8];
    // int count = 0;
    // vector<char> temp;
    // for (int i = 0; i < length; i++) {
    //     int cur = message_in[i];
    //     stack<int> binary;
    //     // cout<<cur<<endl;
    //     while (cur != 0) {
    //         int r = cur % 2;
    //         cur /= 2;
    //         binary.push(r);
    //     }
    //     int binaryL = binary.size();
    //     for (int j = 0; j < 8; j++) {
    //         if (j >= 8 - binaryL) {
    //             orig[count][j] = binary.top();
    //             binary.pop();
    //         } else {
    //             orig[count][j] = 0;
    //         }
    //     }
    //     // for (int j = 0; j < 8; j++) {
    //     //     cout<<orig[count][j];
    //     // }
    //     // cout<<endl;
    //     count++;
    //     if (count == 8) {
    //         for (int b = 7; b >= 0; b--) {
    //             for (int a = 0; a < 8; a++) {
    //                 binary.push(orig[a][b]);
    //                 orig[a][b] = 0;
    //             }
    //             int output = 0;
    //             // for (int j = 0; j < 8; j++) {
    //             //     cout<<binary.top();
    //             //     binary.pop();
    //             // }
    //             // cout<<endl;
    //             for (int j = 0; j < 8; j++) {
    //                 if (binary.top() == 1) {
    //                     output += pow(2, 7 - j);
    //                 }
    //                 binary.pop();
    //             }
    //             //cout<<(char)output;
    //             temp.push_back((char)output);
    //         }
    //         count = 0;
    //     }
    // }

    // // TODO: write your code here
    // for (int i = 0; i < length; i++) {
    //     message_out[i] = temp[i];
    //     // cout<<temp[i];
    // }
    // cout<<endl;
    // for (int i = 0; i < length; i+=8) {
    //     // if (i % 8 == 0 || i != 0) {            
    //     // }
    //     for (int j = 0; j < 8; j++) {
    //         for (int k = 0; k < 8; k++) {
    //             message_out[(i + 7 - k)] = ((message_in[i + j] >> (7 - k) & 00000001) << j) 
    //             | message_out[(i + 7 - k)];
    //         }
    //         //cout<<message_out<<endl;
    //     }
    // }

    for (int i = 7; i < length; i+=8) {
        // if (i % 8 == 0 || i != 0) {            
        // }
        for (int j = 0; j < 8; j++) {
            for (int k = 0; k < 8; k++) {
                message_out[i - j] = ((message_in[i - k] << j & 0x80) >> k) 
                | message_out[i - j];
            }
            //cout<<message_out<<endl;
        }
    }
    
    
    return message_out;
}
