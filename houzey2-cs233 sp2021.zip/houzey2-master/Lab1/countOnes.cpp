/**
 * @file
 * Contains an implementation of the countOnes function.
 */
#include <iostream>
using namespace std;
unsigned countOnes(unsigned input) {
	// TODO: write your code here
	//cout<<input<<endl;
	unsigned counterR = 0x55555555 & input;
	unsigned counterL = 0xAAAAAAAA & input;
	unsigned output = (counterL >> 1) + counterR; //1

	counterR = 0x33333333 & output;
	counterL = 0xcccccccc & output;
	output = (counterL >> 2) + counterR; //2

	counterR = 0x0f0f0f0f & output;
	counterL = 0xf0f0f0f0 & output;
	output = (counterL >> 4) + counterR; //4

	counterR = 0x00ff00ff & output;
	counterL = 0xff00ff00 & output;
	output = (counterL >> 8) + counterR; //8

	counterR = 0x0000ffff & output;
	counterL = 0xffff0000 & output;
	output = (counterL >> 16) + counterR; //16


	//cout<<output<<endl;
	return output;
}
