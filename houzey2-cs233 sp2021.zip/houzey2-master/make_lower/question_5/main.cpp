// compile with g++ -Wall -O0 main.cpp -o array_compare
// and run with ./array_compare

#include <cstdlib>
#include <stdio.h>


int compare(int a, int b) {
    return a - b;
}




int array_compare(int **array1, int **array2, int length) {
    int match_count = 0;

    for (int i = 0; i < length; i++) {
        if ((array1[i] != NULL) && (array2[i] != NULL)) {
            if (compare(*array1[i], *array2[i]) == 0) {  // call this function, DO NOT INLINE
                match_count++;
            }
        }
    }
    return match_count;
}
int main() {
    int *test0_arr1[] = {new int(7), NULL, new int(50), new int(42), new int(10), NULL, new int(1), new int(9)};
    int *test0_arr2[] = {new int(0), new int(1), new int(50), new int(123), new int(99), new int(8), NULL, new int(9)};
    printf("%d \n", array_compare(test0_arr1, test0_arr2, 8));
    int *test1_arr1[] = {new int(4), new int(5), NULL, new int(88), NULL, NULL, new int(98), new int(123), new int(321), new int(555), new int(79), NULL, new int(0), new int(22), NULL};
    int *test1_arr2[] = {new int(88), new int(5), NULL, new int(90), new int(53), new int(42), new int(98), NULL, NULL, new int(66), new int(78), new int(84), new int(54), new int(22), new int(90)};
    printf("%d \n", array_compare(test1_arr1, test1_arr2, 15));
    return 0;
}