#ifndef TRANSPOSE_H
#define TRANSPOSE_H

#define N ((1 << 14) - 3) // 16381 (prime)

/* Function declarations */
void transpose(int **image2, int **image1);

#endif
