#include "transpose.h"
int min(int, int);
// modify this function to add tiling
void transpose(int **A, int **B) {      
    int TILE_SIZE = 16;
    for (int i = 0; i < N; i += TILE_SIZE) {
        for (int j = 0; j < N; j += TILE_SIZE) {
            for (int i1 = i; i1 < min(i + TILE_SIZE, N); i1++) {
                for (int j1 = j; j1 < min(j + TILE_SIZE, N); j1++) {
                    B[i1][j1] = A[j1][i1];
                }
            }
        }
    }
}

