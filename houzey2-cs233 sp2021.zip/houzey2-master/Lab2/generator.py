## a code generator for the ALU chain in the 32-bit ALU
## look at example_generator.py for inspiration
## 
## python generator.py
